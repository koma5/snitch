# Arvet Fuchs 
# start: mysql -p < CreateDB.sql

#Create DB

#Drop Database if exists People;
#Create Database People;
use fifthch_arvet;

#Delete the Tables
Drop Table if exists Name;
Drop Table if exists Ort;
Drop Table if exists Login;

#Create Tables 

create table Name
(
Nummer Integer unsigned not null auto_increment,
Name Varchar(25) not null,
Nachname Varchar(25) not null,
phone Varchar(10),
Telephone Varchar(10),
EMail Varchar(30),
Special Varchar(100),
Geburtsdatum Date,
Strasse Varchar(30),
FK_Ort integer unsigned,
Primary Key (Nummer),
Index (Name)
);

create table Ort
(
Ort_ID Integer unsigned not null auto_increment,
PLZ Smallint(4),
Ort Varchar(20),
Primary Key (Ort_ID)
);

create table Login
(
id Integer unsigned not null auto_increment ,
Username Varchar(150) not null, 
Passwort Varchar(32) not null,
Primary Key (id)
);