<?php include("header.php"); ?>

<?php
  mysql_connect ("5th.ch", "fifthch_arvet","Hellow123")  or die (mysql_error());
  mysql_select_db ("fifthch_arvet");
  $term = $_POST['term'];
  $sql = mysql_query("select Name,Nachname,HandyNr from Name where Name like '%$term%' or Nachname like '%$term%' limit 20");

  $num_rows = mysql_num_rows($sql);
  if ($num_rows > 20) {
  ?>
     
	  <p align="center"> Ihre Suche liefert zuviele Ergebnisse </p>
 <?php 
	 } else {
   while ($row = mysql_fetch_array($sql)){
 ?>
 <div id="dbcontent">
   <table id="dtable">
    <tr>
     <td>First Name: </td> 
     <td><?=$row['Name'];?></td>
    </tr>
   <tr>
     <td>Last Name: </td> 
     <td><?=$row['Nachname'];?></td>
    </tr>
    <tr>
     <td>Phone: </td> 
     <td><?=$row['HandyNr'];?></td>
    </tr>
	</br>
  </table>
  </div>
  <?php
  }
  }
 ?>
  </br> 
   <INPUT TYPE=BUTTON VALUE="Zur&uuml;ck" onClick="history.back()" id="bmidd">
  </br>

<?php include("footer.php"); ?>

