<?php include("header.php"); ?> 


<div id="middle">


   <form action="index.php" method="post">
						Dein Username:<br>
					<input type="text" size="24" maxlength="50"
					name="username"><br><br>

				Dein Passwort:<br>
			<input type="password" size="24" maxlength="50"
			name="password"><br>

	<input type="submit" value="Login">
   </form>
  
 </div>
   
 <?php 
$verbindung = mysql_connect("5th.ch", "fifthch_arvet" , "Hellow123") 
or die("Verbindung zur Datenbank konnte nicht hergestellt werden"); 
mysql_select_db("fifthch_arvet") or die ("Datenbank konnte nicht ausgewählt werden"); 

$username = $_POST["username"]; 
$passwort = md5($_POST["password"]); 

$abfrage = "SELECT username, passwort FROM Login WHERE username LIKE '$username' LIMIT 1"; 
$ergebnis = mysql_query($abfrage); 
$row = mysql_fetch_object($ergebnis); 

if($row->passwort == $passwort) 
    { 
    $_SESSION["username"] = $username; 
    echo "Logged in"; 
    } 
else 
    { 
    echo "Benutzername und/oder Passwort waren falsch. <a href=\"login.php\">Login</a>"; 
    } 

?> 

   <?php include("footer.php"); ?>