<?php include("header.php"); ?> 


<?php 
session_start(); 
?> 



<div id="middle">




<?php 
if(!isset($_SESSION["username"])) 
   { 
   echo "Bitte erst <a href=\"login.php\">einloggen</a>"; 
   exit; 
   } 
?> 
 
   <form action="search.php" method="post">
    Search: <input type="text" name="term"/>
   <input type="submit" name="submit" value="Submit"/> </br> </br>
   </form>

 <!-- <form action="insert.php" method="post">
     <table>
     	<tr>
		<td> First Name: </td>
		<td>  <input type="text" name="Name"/> </td>
     	</tr>
     	<tr>
		<td> Last Name:</td>
		<td>  <input type="text" name="Nachname"/> </td>
     	</tr>
     	<tr>
		<td> Phone: </td>
   		<td> <input type="text" name="HandyNr"/> </td>
     	</tr>
     </table>
    <input type="submit"/>
   </form> -->

</div>

 
<?php include("footer.php"); ?>



