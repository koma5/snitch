<?php include("header.php"); ?>

<layer id="insert">
<?php
  $con = mysql_connect("localhost", "root","")  or die (mysql_error());
  mysql_select_db ("People");

  $sql = "Insert into Name (Name,Nachname,HandyNr) VALUES ('$_POST[Name]','$_POST[Nachname]','$_POST[HandyNr]')";
 
  if (!mysql_query($sql,$con))
     {
     die('Error' . mysql_error());
     }
  echo "1 record added";
?>

 </br></br></br></br>
   <INPUT TYPE=BUTTON VALUE="Zur&uuml;ck" onClick="history.back()" id="bmidd">

</layer>

<?php include("footer.php"); ?>

