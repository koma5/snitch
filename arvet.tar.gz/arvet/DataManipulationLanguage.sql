# Arvet Fuchs 
# start: mysql -p < CreateDB.sql
#use mysql;
# Delete Password from root
#delete from user where user='root' and host = '%';
#update user set password=password('') where user='root';
#flush privileges;

# shows user with password
# select host, user, password from user;

use fifthch_arvet;

# show columns from Name;

#Insert into Name
insert into Name (Name, Nachname,FK_Ort) values ('Arvet', 'Fuchs','1');
insert into Name (Name, Nachname,FK_Ort) values ('Dario', 'Rota','2');
insert into Name (Name, Nachname,FK_Ort) values ('Marco', 'Koch','3');
insert into Name (Name, Nachname) values ('Nico', 'Landolt');
insert into Name (Name, Nachname) values ('Nick', 'Mueller');
insert into Name (Name, Nachname) values ('William', 'Marty');
insert into Name (Name, Nachname) values ('Florian', 'Ochsner');
insert into Name (Name, Nachname) values ('Fabian', 'Haerri');
insert into Name (Name, Nachname) values ('Vanessa', 'Kilchenman');
insert into Name (Name, Nachname) values ('Lars', 'Helfenstein');
insert into Name (Name, Nachname) values ('Kenny', 'Mueller');
insert into Name (Name, Nachname) values ('Artimus', 'Petrig');
insert into Name (Name,Nachname) values ('Ivana','Peterka');

#Insert into Ort
insert into Ort (PLZ,Ort) values ('8840','Einsiedeln');
insert into Ort (PLZ,Ort) values ('8800','Thalwil');
insert into Ort (PLZ,Ort) values ('8857','Vorderthal');

#Insert into Login
insert into Login(Username,Passwort) values ('arvet','098f6bcd4621d373cade4e832627b4f6');

#Create View(s)
#http://www.java2s.com/Tutorial/MySQL/0180__View/CreatingaViewwithJoinedTables.htm
#create view myView (Name1,Nachname1,Ort1) as Select Name, Nachname, Ort from Name,Ort where FK_Ort = Ort_ID;
#create view myView Select Name, Nachname,Ort from Name,Ort where FK_Ort = Ort_ID;

