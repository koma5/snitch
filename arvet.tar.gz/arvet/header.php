<html>
 <head>
  <title> Test </title>
  <link rel="stylesheet" type="text/css" href="css/style.css">
 </head>
 <body>
 <div id="header">
 <p> Search the Friends </p>
 </div>

